ORDERED T_N CONFIGURATIONS IN CONSTITUTIVE SETS
================================================

Files
-----
TN_constitutive_preprint.tex
    Complete 29-page LaTeX manuscript.

TN_constitutive_preprint.pdf
    Compiled manuscript.

TN_constitutive_references.bib
    Editable BibTeX database for the references used in the manuscript.
    For maximum portability, the supplied .tex file contains an inline
    thebibliography environment and therefore compiles without running BibTeX.

verify_TN_computations.py
    Exact SymPy verification of the displayed algebraic computations,
    including the resultant and Sturm calculations, the exact T_4 and T_6
    parameterizations, pairwise rank checks, Hermite interpolation data, and
    the weighted-minor identities.

Compilation
-----------
From this directory, run

    latexmk -pdf -interaction=nonstopmode -halt-on-error TN_constitutive_preprint.tex

A sufficiently recent TeX Live installation containing amsart, hyperref,
cleveref, aliascnt, microtype, listings, and the standard AMS packages is
required.

Exact verification
------------------
Run

    python verify_TN_computations.py

The script requires Python 3 and SymPy.

Scope of the manuscript
-----------------------
The manuscript proves an explicit counterexample to universal nonexistence
under the weak ordered T_N definition, constructs exact nondegenerate finite
T_4 and T_6 configurations compatible with a quadratic entropy graph, and
proves several rank-one-free and N-independent structural obstructions.  It
does not claim to solve the remaining global problem of realizing a
nondegenerate T_N inside an entirely rank-one-free constitutive surface that
is strictly hyperbolic and genuinely nonlinear on one convex state space.

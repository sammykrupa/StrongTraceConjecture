#!/usr/bin/env python3
"""Exact symbolic checks for TN_constitutive_preprint.tex.

All assertions use SymPy exact rational arithmetic.  The script verifies the
explicit potential, the resultant/Sturm calculation, the finite T4 and T6
data, both polynomial interpolants, and the weighted determinant
cancellations.
"""

from __future__ import annotations

import sympy as sp


def sign_changes(signs: list[int]) -> int:
    """Count sign changes after discarding zeros (Sturm convention)."""
    nonzero = [s for s in signs if s != 0]
    return sum(a != b for a, b in zip(nonzero, nonzero[1:]))


def main() -> None:
    x, y, t = sp.symbols("x y t", real=True)
    R = sp.Rational

    # ------------------------------------------------------------------
    # 1. Explicit quartic potential and its axis calculations.
    # ------------------------------------------------------------------
    Phi = (
        R(3, 4) * x**4
        + R(7, 6) * (x**3 - x) * y
        + (1 - R(5, 2) * x) * y**2
        - (R(10, 3) + R(25, 6) * x) * y**3
    )
    F = sp.Matrix([sp.diff(Phi, x), sp.diff(Phi, y)])
    expected_F = sp.Matrix(
        [
            3 * x**3 + (R(7, 2) * x**2 - R(7, 6)) * y
            - R(5, 2) * y**2 - R(25, 6) * y**3,
            R(7, 6) * (x**3 - x) + (2 - 5 * x) * y
            - (10 + R(25, 2) * x) * y**2,
        ]
    )
    assert sp.simplify(F - expected_F) == sp.zeros(2, 1)

    eta = (x**2 + y**2) / 2
    q = sp.expand(x * F[0] + y * F[1] - Phi)
    assert sp.simplify(q.subs(y, 0) - R(9, 4) * x**4) == 0

    U_minus = {x: -1, y: 0}
    U_plus = {x: 1, y: 0}
    assert F.subs(U_minus) == sp.Matrix([-3, 0])
    assert F.subs(U_plus) == sp.Matrix([3, 0])
    assert eta.subs(U_minus) == eta.subs(U_plus) == R(1, 2)
    assert q.subs(U_minus) == q.subs(U_plus) == R(9, 4)

    Hess_axis = sp.hessian(Phi, (x, y)).subs(y, 0)
    expected_Hess_axis = sp.Matrix(
        [
            [9 * x**2, R(7, 6) * (3 * x**2 - 1)],
            [R(7, 6) * (3 * x**2 - 1), 2 - 5 * x],
        ]
    )
    assert sp.simplify(Hess_axis - expected_Hess_axis) == sp.zeros(2, 2)

    third_axis = {
        "xxx": sp.diff(Phi, x, 3).subs(y, 0),
        "xxy": sp.diff(Phi, x, 2, y, 1).subs(y, 0),
        "xyy": sp.diff(Phi, x, 1, y, 2).subs(y, 0),
        "yyy": sp.diff(Phi, y, 3).subs(y, 0),
    }
    expected_third_axis = {
        "xxx": 18 * x,
        "xxy": 7 * x,
        "xyy": -5,
        "yyy": -(20 + 25 * x),
    }
    for key in third_axis:
        assert sp.simplify(third_axis[key] - expected_third_axis[key]) == 0

    Q = (
        R(7, 6) * (3 * x**2 - 1) * t**2
        + (9 * x**2 + 5 * x - 2) * t
        - R(7, 6) * (3 * x**2 - 1)
    )
    H_cubic = 18 * x + 21 * x * t - 15 * t**2 - (20 + 25 * x) * t**3
    P_resultant = (
        129007296 * x**8
        + 235355760 * x**7
        + 80940141 * x**6
        - 64110420 * x**5
        - 27496701 * x**4
        + 10403280 * x**3
        + 1618495 * x**2
        - 1203500 * x
        + 236425
    )
    assert sp.factor(sp.resultant(Q, H_cubic, t) - P_resultant / 216) == 0

    sturm = sp.sturm(P_resultant, x)
    signs_minus = [int(sp.sign(s.subs(x, -1))) for s in sturm]
    signs_plus = [int(sp.sign(s.subs(x, 1))) for s in sturm]
    expected_minus = [1, -1, 1, 1, -1, -1, -1, 1, 1]
    expected_plus = [1, 1, 1, -1, -1, 1, -1, 1, 1]
    assert signs_minus == expected_minus
    assert signs_plus == expected_plus
    assert sign_changes(signs_minus) == sign_changes(signs_plus) == 4
    assert sp.count_roots(P_resultant, -1, 1) == 0

    # ------------------------------------------------------------------
    # 2. Exact finite nondegenerate T4.
    # ------------------------------------------------------------------
    X = [
        sp.Matrix([[-3, -R(68, 5)], [0, 0], [R(9, 2), R(24, 5)]]),
        sp.Matrix([[-1, -R(94, 15)], [0, 0], [R(1, 2), R(44, 5)]]),
        sp.Matrix([[1, R(98, 15)], [0, 0], [R(1, 2), -R(28, 5)]]),
        sp.Matrix([[3, 0], [0, 0], [R(9, 2), 0]]),
    ]
    c = [
        sp.Matrix([-R(34, 15), 0, R(4, 5)]),
        sp.Matrix([-R(2, 15), 0, -R(8, 5)]),
        sp.Matrix([R(14, 15), 0, -R(4, 5)]),
        sp.Matrix([R(22, 15), 0, R(8, 5)]),
    ]
    speeds = [3, -2, 7, 0]
    C = [ci * sp.Matrix([[1, si]]) for ci, si in zip(c, speeds)]
    P0 = sp.Matrix([[R(23, 15), 0], [0, 0], [R(29, 10), 0]])

    assert sum(c, sp.zeros(3, 1)) == sp.zeros(3, 1)
    assert sum((si * ci for si, ci in zip(speeds, c)), sp.zeros(3, 1)) == sp.zeros(3, 1)
    assert sum(C, sp.zeros(3, 2)) == sp.zeros(3, 2)
    for i in range(4):
        rhs = P0 + sum(C[:i], sp.zeros(3, 2)) + 2 * C[i]
        assert rhs == X[i]
        assert C[i].rank() == 1

    expected_dets = {
        (0, 1): R(112, 3),
        (0, 2): R(584, 15),
        (0, 3): -R(144, 5),
        (1, 2): -R(144, 5),
        (1, 3): -R(904, 15),
        (2, 3): R(112, 3),
    }
    actual_dets: dict[tuple[int, int], sp.Expr] = {}
    for i in range(4):
        for j in range(i + 1, 4):
            minor_13 = (X[i] - X[j]).extract([0, 2], [0, 1])
            det = sp.factor(minor_13.det())
            actual_dets[(i, j)] = det
            assert det == expected_dets[(i, j)]
            assert (X[i] - X[j]).rank() == 2

    # ------------------------------------------------------------------
    # 3. Hermite interpolation realizing the four constitutive matrices.
    # ------------------------------------------------------------------
    phi = sp.expand(
        (x - 3) ** 2
        * (
            28 * x**5
            + 75 * x**4
            - 1502 * x**3
            - 7548 * x**2
            - 7718 * x
            - 807
        )
        / 5760
    )
    hermite_data = {
        -3: (-36, R(68, 5)),
        -1: (R(38, 15), R(94, 15)),
        1: (-R(182, 15), -R(98, 15)),
        3: (0, 0),
    }
    for node, (value, derivative) in hermite_data.items():
        assert sp.simplify(phi.subs(x, node) - value) == 0
        assert sp.simplify(sp.diff(phi, x).subs(x, node) - derivative) == 0

    phi_third = sp.factor(sp.diff(phi, x, 3))
    R_poly = 245 * x**4 - 465 * x**3 - 4250 * x**2 + 2139 * x + 6013
    assert sp.factor(phi_third - R_poly / 240) == 0
    assert [R_poly.subs(x, z) for z in (-2, -1, 1, 2)] == [-7625, 334, 3682, -6509]

    # Verify G(U_i)=X_i for Phi_{L,gamma}; L and gamma remain symbolic.
    L, gamma = sp.symbols("L gamma")
    Phi_interp = phi + L * y**2 / 2 + gamma * y**3 / 6
    F_interp = sp.Matrix([sp.diff(Phi_interp, x), sp.diff(Phi_interp, y)])
    eta_interp = (x**2 + y**2) / 2
    q_interp = sp.expand(x * F_interp[0] + y * F_interp[1] - Phi_interp)
    nodes = [-3, -1, 1, 3]
    for i, node in enumerate(nodes):
        G_node = sp.Matrix(
            [
                [node, -F_interp[0].subs({x: node, y: 0})],
                [0, -F_interp[1].subs({x: node, y: 0})],
                [eta_interp.subs({x: node, y: 0}), -q_interp.subs({x: node, y: 0})],
            ]
        )
        assert sp.simplify(G_node - X[i]) == sp.zeros(3, 2)

    # ------------------------------------------------------------------
    # 4. Exact finite nondegenerate T6 and its potential interpolation.
    # ------------------------------------------------------------------
    U6 = [(-2, 0), (-1, 1), (0, -1), (1, 2), (2, -1), (3, 1)]
    X6 = [
        sp.Matrix([[-2, 0], [0, 0], [2, 0]]),
        sp.Matrix([[-1, -R(22, 21)], [1, R(16, 21)], [1, -R(113, 63)]]),
        sp.Matrix([[0, -R(41, 21)], [-1, R(110, 21)], [R(1, 2), R(415, 126)]]),
        sp.Matrix([[1, 0], [2, 5], [R(5, 2), R(5, 2)]]),
        sp.Matrix([[2, R(89, 21)], [-1, -R(38, 21)], [R(5, 2), R(479, 126)]]),
        sp.Matrix([[3, -R(38, 21)], [1, -R(22, 21)], [5, -R(178, 63)]]),
    ]
    c6 = [
        sp.Matrix([-R(43, 21), -R(5, 21), -R(50, 63)]),
        sp.Matrix([-R(11, 21), R(8, 21), -R(113, 126)]),
        sp.Matrix([R(5, 21), -R(17, 21), -R(44, 63)]),
        sp.Matrix([R(13, 21), R(23, 21), R(41, 63)]),
        sp.Matrix([R(17, 21), -R(20, 21), R(41, 126)]),
        sp.Matrix([R(19, 21), R(11, 21), R(89, 63)]),
    ]
    speeds6 = [0, 1, -3, 1, 3, -2]
    C6 = [ci * sp.Matrix([[1, si]]) for ci, si in zip(c6, speeds6)]
    P6 = sp.Matrix([[R(44, 21), 0], [R(10, 21), 0], [R(226, 63), 0]])

    assert sum(c6, sp.zeros(3, 1)) == sp.zeros(3, 1)
    assert sum(
        (si * ci for si, ci in zip(speeds6, c6)), sp.zeros(3, 1)
    ) == sp.zeros(3, 1)
    assert sum(C6, sp.zeros(3, 2)) == sp.zeros(3, 2)
    for i in range(6):
        rhs = P6 + sum(C6[:i], sp.zeros(3, 2)) + 2 * C6[i]
        assert rhs == X6[i]
        assert C6[i].rank() == 1

    expected_dets6 = {
        (0, 1): R(38, 21),
        (0, 2): R(179, 21),
        (0, 3): 15,
        (0, 4): -3,
        (0, 5): -R(24, 7),
        (1, 2): R(8, 3),
        (1, 3): R(52, 7),
        (1, 4): R(20, 7),
        (1, 5): -R(152, 21),
        (2, 3): -R(128, 21),
        (2, 4): -R(296, 21),
        (2, 5): -R(134, 7),
        (3, 4): R(124, 21),
        (3, 5): -R(292, 21),
        (4, 5): R(90, 7),
    }
    for i in range(6):
        for j in range(i + 1, 6):
            det12 = sp.factor((X6[i] - X6[j]).extract([0, 1], [0, 1]).det())
            assert det12 == expected_dets6[(i, j)]
            assert (X6[i] - X6[j]).rank() == 2

    b6 = -(
        (x + 2)
        * (33 * x**4 + 49 * x**3 - 623 * x**2 + 141 * x + 1100)
        / 420
    )
    a6 = -(
        (x + 2) ** 2
        * (
            782221 * x**9
            - 7916652 * x**8
            + 27685989 * x**7
            - 29453268 * x**6
            - 38283441 * x**5
            + 98693292 * x**4
            - 39490369 * x**3
            - 23127372 * x**2
            + 21009600 * x
            - 14940000
        )
        / 18144000
    )
    Phi6 = sp.expand(a6 + b6 * y)
    F6 = sp.Matrix([sp.diff(Phi6, x), sp.diff(Phi6, y)])
    eta6 = (x**2 + y**2) / 2
    q6 = sp.expand(x * F6[0] + y * F6[1] - Phi6)
    for i, (xi, yi) in enumerate(U6):
        G_node = sp.Matrix(
            [
                [xi, -F6[0].subs({x: xi, y: yi})],
                [yi, -F6[1].subs({x: xi, y: yi})],
                [eta6.subs({x: xi, y: yi}), -q6.subs({x: xi, y: yi})],
            ]
        )
        assert sp.simplify(G_node - X6[i]) == sp.zeros(3, 2)

    # ------------------------------------------------------------------
    # 5. Weighted minor identity for the displayed T4 and T6.
    # ------------------------------------------------------------------
    theta = [R(1, 15), R(2, 15), R(4, 15), R(8, 15)]
    assert sum(theta) == 1
    weighted_sum = sum(
        theta[i] * theta[j] * actual_dets[(i, j)]
        for i in range(4)
        for j in range(i + 1, 4)
    )
    assert sp.simplify(weighted_sum) == 0
    assert sum((theta[i] * X[i] for i in range(4)), sp.zeros(3, 2)) == P0

    theta6 = [R(1, 63), R(2, 63), R(4, 63), R(8, 63), R(16, 63), R(32, 63)]
    assert sum(theta6) == 1
    assert sum((theta6[i] * X6[i] for i in range(6)), sp.zeros(3, 2)) == P6
    weighted_sums6: dict[tuple[int, int], sp.Expr] = {}
    for rows in ((0, 1), (0, 2), (1, 2)):
        weighted_sums6[rows] = sp.simplify(
            sum(
                (
                    theta6[i]
                    * theta6[j]
                    * (X6[i] - X6[j]).extract(list(rows), [0, 1]).det()
                )
                for i in range(6)
                for j in range(i + 1, 6)
            )
        )
        assert weighted_sums6[rows] == 0

    # ------------------------------------------------------------------
    # 6. Two generic algebraic identities used in the text.
    # ------------------------------------------------------------------
    a, b, c0, d = sp.symbols("a b c0 d")
    g = a + b * t + c0 * t**2 + d * t**3
    assert sp.expand((sp.diff(g, t).subs(t, 0) + sp.diff(g, t).subs(t, 1)) / 2
                     - (g.subs(t, 1) - g.subs(t, 0))
                     - sp.diff(g, t, 3) / 12) == 0

    # Determinant variance identity for three symbolic 2x2 matrices.
    th1, th2 = sp.symbols("th1 th2")
    th3 = 1 - th1 - th2
    entries = sp.symbols("z0:12")
    Y = [sp.Matrix(2, 2, entries[4 * i: 4 * (i + 1)]) for i in range(3)]
    lhs = sum((w * M.det() for w, M in zip([th1, th2, th3], Y)), sp.Integer(0))
    lhs -= (th1 * Y[0] + th2 * Y[1] + th3 * Y[2]).det()
    rhs = (
        th1 * th2 * (Y[0] - Y[1]).det()
        + th1 * th3 * (Y[0] - Y[2]).det()
        + th2 * th3 * (Y[1] - Y[2]).det()
    )
    assert sp.expand(lhs - rhs) == 0

    print("All exact symbolic checks passed.")
    print(f"Sturm signs at -1: {signs_minus}; variations = {sign_changes(signs_minus)}")
    print(f"Sturm signs at  1: {signs_plus}; variations = {sign_changes(signs_plus)}")
    print(f"Weighted T4 minor sum: {weighted_sum}")
    print(f"Weighted T6 minor sums: {weighted_sums6}")


if __name__ == "__main__":
    main()
